#ifndef CALCGRADES_H
#define CALCGRADES_H

int calcGrades(int length, int arr[]);


#endif
